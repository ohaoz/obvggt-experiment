# OBVGGT Monodepth 重跑报告（KV策略生效版）

## 1. 结论
- 状态：**已完成**
- 运行区间：`2026-03-04 09:59:14` 到 `2026-03-04 10:47:03`（约 47 分 49 秒）
- 数据集覆盖：`sintel / bonn / kitti / nyu / scannet`（5/5）
- 结果文件：5 个 `metric.json` 均已生成

## 2. 运行信息
- 服务器：`192.168.166.9:2222`（3号机）
- 运行目录：`/mnt/data2/OBVGGT/runs/runs/20260304_014555_msi3_monodepth_manual`
- 日志文件：`/mnt/data2/OBVGGT/runs/runs/20260304_014555_msi3_monodepth_manual/monodepth.log`
- 输出目录：`/mnt/data2/OBVGGT/code/OBVGGT/eval_results/monodepth`

## 3. KV 策略生效证据
日志中每个数据集的 `launch` 阶段均出现：
- `[kv_cache] enabled; cfg={'enable': True}`

对应日志关键行（节选）：
- sintel: `line 39`
- bonn: `line 1169`
- kitti: `line 1749`
- nyu: `line 3064`
- scannet: `line 3084`

## 4. 时间线（关键节点）
- `09:59:14` START rerun
- `09:59:14` launch sintel
- `10:02:54` eval_metrics sintel
- `10:02:59` launch bonn
- `10:05:14` eval_metrics bonn
- `10:05:21` launch kitti
- `10:09:06` eval_metrics kitti
- `10:09:17` launch nyu
- `10:11:56` eval_metrics nyu
- `10:12:00` launch scannet
- `10:45:57` eval_metrics scannet
- `10:47:03` DONE

## 5. 指标汇总（metric.json）

| 数据集 | Abs Rel | Sq Rel | RMSE | Log RMSE | δ < 1.25 | δ < 1.25^2 | δ < 1.25^3 |
|---|---:|---:|---:|---:|---:|---:|---:|
| sintel | 0.2543 | 1.4672 | 4.0014 | 0.3720 | 0.6851 | 0.8343 | 0.9005 |
| bonn | 0.0515 | 0.0346 | 0.2399 | 0.1036 | 0.9711 | 0.9837 | 0.9895 |
| kitti | 0.0718 | 0.3916 | 3.8340 | 0.1209 | 0.9468 | 0.9852 | 0.9934 |
| nyu | 0.0550 | 0.0326 | 0.2768 | 0.0953 | 0.9585 | 0.9881 | 0.9953 |
| scannet | 0.0289 | 0.0073 | 0.1190 | 0.0545 | 0.9863 | 0.9963 | 0.9990 |

## 6. 完整性检查
- 进程检查：结束时无残留 `launch.py/eval_metrics.py` 任务
- 文件检查：`sintel/bonn/kitti/nyu/scannet` 的 `metric.json` 均存在
- 异常检查：本次关键日志中未出现 `Traceback` / `NotImplementedError`

