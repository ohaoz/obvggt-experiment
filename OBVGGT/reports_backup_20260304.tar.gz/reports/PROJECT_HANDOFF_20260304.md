# OBVGGT 项目交接说明（2026-03-04）

## 0. 文档目的
- 给下一位工程师 5 分钟内建立完整上下文：当前做到哪里、哪里卡住、下一步怎么继续。
- 本文严格对齐：
  - `AGENTS.md`（尤其 7.4、8.5、8.6、8.7 的判定与命令规范）
  - 现有报告：`OBVGGT/reports/video_depth_sys_benchmark_20260304/*.md`

## 1. 当前总体状态（结论先看）
- `video_depth` 的 KV 系统评测已完成关键闭环（FPS / latency / peak memory / evict/hit），并有明确结论。
- `8.5 mv_recon`：已完成（可用结果已落盘）。
- `8.6 pose_co3d`：未完整完成（CO3D 注释缺失，脚本会跳过所有类别）。
- `8.7 KV 最小集合`：主线已覆盖（monodepth + video_depth + mv_recon），但 canonical video_depth 目录仍缺部分项，属于“有替代证据但非完全同路径”。

按 `AGENTS.md` 7.4 判定：当前整体更接近 `PARTIAL_DONE`，不是全量 `DONE`。

## 2. 已产出成果与证据路径

### 2.1 video_depth（KV 系统评测）
- 本地完整报告：
  - `C:/Users/zgg20/Documents/trae_projects/vggt/OBVGGT/reports/video_depth_sys_benchmark_20260304/REPORT_COMPLETE_20260304.md`
- 服务器 record：
  - `/mnt/data2/OBVGGT/runs/records/20260304_130631_msi3_video_depth_sys_benchmark_obcache_retry1.md`
  - `/mnt/data2/OBVGGT/runs/records/20260304_194844_msi3_video_depth_sys_benchmark_obcache_retry2_continue.md`
- 关键结论（已验证）：
  - `sintel/kitti`：OBCache 显存峰值显著下降（约 -56% ~ -59%），吞吐有下降（约 -8% ~ -16%）。
  - `bonn`：baseline 全 OOM（0/5），obcache 全通过（5/5）。
  - 结论重点是“可运行性 + 显存收益”，不是单纯精度提升。

### 2.2 8.5 / 8.6 / 8.7 执行报告
- 本地报告：
  - `C:/Users/zgg20/Documents/trae_projects/vggt/OBVGGT/reports/video_depth_sys_benchmark_20260304/REPORT_8p5_8p6_8p7_20260304.md`
- 对应服务器 record：
  - `/mnt/data2/OBVGGT/runs/records/20260304_203951_msi3_eval_8p5_8p6_8p7.md`
- 对应日志：
  - `/mnt/data2/OBVGGT/runs/runs/20260304_203951_msi3_eval_8p5_8p6_8p7/mv_recon.log`
  - `/mnt/data2/OBVGGT/runs/runs/20260304_203951_msi3_eval_8p5_8p6_8p7/pose_co3d.log`

## 3. 各任务状态（按 AGENTS 章节）

### 3.1 8.5 Multi-view Reconstruction（mv_recon）
状态：`DONE`（就执行结果而言）。

已踩坑与修复：
1. 缺包：`tifffile` -> 已安装。
2. `AGENTS.md` 给的命令是 `--model_name OBVGGT`，但当前 `eval/mv_recon/launch.py` 实际只支持 `StreamVGGT` / `VGGT`，传 `OBVGGT` 会 `NotImplementedError`。
3. 最终采用：`--model_name StreamVGGT --weights ../ckpt/checkpoints.pth`，7scenes + NRGBD 跑通并产出 `summary_metrics.json`。

结果目录：
- `/mnt/data2/OBVGGT/runs/eval_results/mv_recon/StreamVGGT_checkpoints/7scenes/summary_metrics.json`
- `/mnt/data2/OBVGGT/runs/eval_results/mv_recon/StreamVGGT_checkpoints/NRGBD/summary_metrics.json`

### 3.2 8.6 Camera Pose Estimation（CO3D）
状态：`PARTIAL_DONE`（命令执行了，但无有效评测输出）。

现象：
- `test_co3d.py` 逐类报：`Annotation file not found for <category>, skipping`。
- `../eval_results/pose_co3d/` 创建成功，但无 `pose_summary.json`。

根因：
- `--co3d_anno_dir` 下缺少 `<category>_test.jgz`。
- 当前服务器常见挂载路径未找到 CO3D 注释集。

### 3.3 8.7 KV 策略评测（防评测不敏感）
状态：`DONE with caveat`。

解释：
- monodepth：5 个数据集 metric 文件齐。
- video_depth：核心系统评测已齐（retry1/retry2），但 canonical `eval_results/video_depth` 下仍缺 `bonn/kitti`。
- mv_recon：本次已跑齐 7scenes + NRGBD。

如果严格要求同一 canonical 目录“一键齐全”，需补回 `video_depth/bonn`、`video_depth/kitti`。

## 4. CO3D 下载可行性（关键阻塞）

截至 2026-03-04 实测（3号机）：
- `/mnt/data2` 可用约 `4.5T`
- `/mnt/data` 可用约 `261G`

CO3D 官方体量：
- 完整数据约 `5.5TB`
- 单序列子集约 `8.9GB`

结论：
- 现在不能在 3号机直接下“完整 CO3D”（空间不足）。
- 可下小子集，但通常不足以支持完整 CO3D pose 评测。

建议：
- 要完整 8.6，请改到有 `>=6TB` 可用空间的机器准备 CO3D 全量（含注释）。

## 5. 环境变更记录（已发生）
- conda env: `obvggt`
- 已安装：
  - `tifffile`
  - `pycolmap==3.10.0`
  - `pyceres==2.3`
- 已安装 LightGlue：
  - `~/LightGlue`
  - `pip install -e ~/LightGlue`

## 6. 下一位工程师的最短续跑路径

### 6.1 先确认基础环境
```bash
ssh -p 2222 szw@192.168.166.9
conda activate obvggt
export STREAMVGGT_CODE=/mnt/data2/OBVGGT/code/OBVGGT
export STREAMVGGT_DATA=/mnt/data2/OBVGGT/data
export STREAMVGGT_RUNS=/mnt/data2/OBVGGT/runs
cd $STREAMVGGT_CODE/src
```

### 6.2 核对关键结果是否在
```bash
python - <<'PY'
import os
paths=[
'../eval_results/monodepth/sintel_OBVGGT/metric.json',
'../eval_results/monodepth/bonn_OBVGGT/metric.json',
'../eval_results/monodepth/kitti_OBVGGT/metric.json',
'../eval_results/monodepth/nyu_OBVGGT/metric.json',
'../eval_results/monodepth/scannet_OBVGGT/metric.json',
'../eval_results/mv_recon/StreamVGGT_checkpoints/7scenes/summary_metrics.json',
'../eval_results/mv_recon/StreamVGGT_checkpoints/NRGBD/summary_metrics.json',
'../eval_results/pose_co3d/pose_summary.json',
]
for p in paths:
    print(('OK  ' if os.path.isfile(p) else 'MISS'), p)
PY
```

### 6.3 若继续补 8.6（CO3D）
1. 先准备两套路径：
- `--co3d_dir`：图像数据根目录（按类别分目录）
- `--co3d_anno_dir`：包含 `<category>_test.jgz`

2. 再跑：
```bash
python eval/pose_evaluation/test_co3d.py \
  --co3d_dir /PATH/TO/CO3D \
  --co3d_anno_dir /PATH/TO/CO3D_ANNO \
  --seed 0 2>&1 | tee $RUN_DIR/pose_co3d.log
```

3. 成功判据：
- `../eval_results/pose_co3d/pose_summary.json` 存在
- 日志中无全量 `Annotation file not found ... skipping`

## 7. 已知“文档与代码不一致”点（务必先看）
- `AGENTS.md` 8.5 示例里 `--model_name OBVGGT` 与当前代码不一致，会直接报 `NotImplementedError`。
- 在不改源码的前提下，当前可执行路径是 `--model_name StreamVGGT`。

## 8. 交接建议（避免重复踩坑）
1. 先看 record，再开跑：
- `/mnt/data2/OBVGGT/runs/records/*.md`
2. 每次开新 run 前先写 record（AGENTS 强制要求）。
3. 每次跑后执行异常扫描（AGENTS 7.4）：
```bash
grep -nE "NotImplementedError|metrics failed|WARNING .* failed|Traceback" $RUN_DIR/*.log || true
```
4. 凡是“路径不确定/数据不确定”，先 `find + ls` 核对再启动长任务。

## 9. 本文版本
- Author: Codex 协作记录
- Date: 2026-03-04
- Scope: 截至本日期的 msi_server（3号机）OBVGGT 评测状态快照
