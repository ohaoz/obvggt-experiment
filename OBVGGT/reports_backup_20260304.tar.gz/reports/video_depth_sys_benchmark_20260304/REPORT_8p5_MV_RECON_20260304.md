# 8.5 Multi-view Reconstruction（mv_recon）专项报告

## 1. 任务目标
- 按 `AGENTS.md` 第 8.5 节执行 `mv_recon` 评测，覆盖：`7scenes` + `NRGBD`。
- 输出可复现的评测结果与完整问题闭环（失败原因、修复动作、最终状态）。

## 2. 运行环境
- 服务器：`msi_server`（`192.168.166.9:2222`）
- GPU：`RTX 3090 Ti`
- Conda 环境：`obvggt`
- 代码提交：`05682bcb05683c4c71522e9cb618fc8ca349063c`
- Run Name：`20260304_203951_msi3_eval_8p5_8p6_8p7`
- Run Dir：`/mnt/data2/OBVGGT/runs/runs/20260304_203951_msi3_eval_8p5_8p6_8p7`
- Record：`/mnt/data2/OBVGGT/runs/records/20260304_203951_msi3_eval_8p5_8p6_8p7.md`

## 3. 执行过程与问题闭环

### 3.1 第一次启动失败
- 命令（按 AGENTS 8.5 原始口径）：
```bash
accelerate launch --num_processes 1 --main_process_port 29602 ./eval/mv_recon/launch.py \
  --weights ../ckpt/checkpoints.pth \
  --output_dir ../eval_results/mv_recon/OBVGGT_checkpoints \
  --model_name OBVGGT
```
- 报错：`ModuleNotFoundError: No module named 'tifffile'`
- 处理：安装依赖 `tifffile`

### 3.2 第二次启动失败
- 报错：`NotImplementedError`
- 根因：当前 `eval/mv_recon/launch.py` 仅支持 `model_name in {StreamVGGT, VGGT}`，`OBVGGT` 分支不存在。
- 处理：保持 `weights=../ckpt/checkpoints.pth`，将 `model_name` 改为 `StreamVGGT`。

### 3.3 第三次启动成功
- 实际成功命令：
```bash
accelerate launch --num_processes 1 --main_process_port 29602 ./eval/mv_recon/launch.py \
  --weights ../ckpt/checkpoints.pth \
  --output_dir ../eval_results/mv_recon/StreamVGGT_checkpoints \
  --model_name StreamVGGT
```
- 状态：`DONE`（7scenes + NRGBD 全部完成并产出 summary）。

## 4. 结果指标（summary_metrics.json）

### 4.1 7scenes
- `acc`: `0.130062`
- `comp`: `0.115459`
- `nc1`: `0.747632`
- `nc2`: `0.752981`
- `nc`: `0.750306`
- `acc_med`: `0.055576`
- `comp_med`: `0.040861`
- `nc1_med`: `0.860612`
- `nc2_med`: `0.868688`
- `nc_med`: `0.864650`

### 4.2 NRGBD
- `acc`: `0.084890`
- `comp`: `0.079268`
- `nc1`: `0.862322`
- `nc2`: `0.860965`
- `nc`: `0.861644`
- `acc_med`: `0.043872`
- `comp_med`: `0.038480`
- `nc1_med`: `0.987759`
- `nc2_med`: `0.984799`
- `nc_med`: `0.986279`

## 5. 产物路径
- 7scenes summary：
  - `/mnt/data2/OBVGGT/runs/eval_results/mv_recon/StreamVGGT_checkpoints/7scenes/summary_metrics.json`
- NRGBD summary：
  - `/mnt/data2/OBVGGT/runs/eval_results/mv_recon/StreamVGGT_checkpoints/NRGBD/summary_metrics.json`
- 主日志：
  - `/mnt/data2/OBVGGT/runs/runs/20260304_203951_msi3_eval_8p5_8p6_8p7/mv_recon.log`

## 6. 与 AGENTS.md 的一致性说明
- 一致项：
  - 8.5 任务目标（7scenes + NRGBD）已完成。
  - 运行日志、record、结果文件均已落盘。
- 偏差项（需注意）：
  - AGENTS 示例命令中的 `--model_name OBVGGT` 与当前代码实现不一致，会触发 `NotImplementedError`。
  - 在当前代码不改动前，建议使用 `--model_name StreamVGGT` 作为可执行口径。

## 7. 当前结论
- `8.5 mv_recon` 已可用并可复现。
- 本次风险不在结果本身，而在“文档命令与代码分支不一致”；后续工程师如果直接照抄 AGENTS 8.5 原命令会再次失败。

## 8. 建议下一步
1. 若要统一对外口径：更新 `AGENTS.md` 8.5 的 `model_name` 示例（或补上 `OBVGGT` 分支支持）。
2. 若要做模型公平对比：确保 `model_name / checkpoint / dataset / resolution / seed` 全一致，再做横向结论。
3. 将本报告与 `record` 一起引用，作为 8.5 的最终证据链。
