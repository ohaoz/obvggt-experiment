# OBVGGT OBCache 序列评测完整报告（video_depth）

## 1. 报告结论（先看）
- 本次已经完成“从纯精度指标扩展到系统指标”的最小闭环：`FPS / 单帧延迟 / 峰值显存 / KV驱逐与命中统计`。
- 在可比数据集（`sintel`、`kitti`）上，`OBCache` 结论很一致：
  - 显存峰值明显下降（`reserved` 约 `-56% ~ -59%`）
  - 吞吐下降（`FPS` 约 `-8% ~ -16%`）
- 在高压场景 `bonn` 上，`baseline` 全部 OOM（`0/5`），而 `OBCache` 全部跑通（`5/5`），这是本次最关键收益。
- 因此当前阶段可给出的结论是：
  - `OBCache` 的主要价值是 **可运行性 + 显存压降**；
  - 不是提升吞吐，也不是在所有数据集上必然提升深度精度。

## 2. 背景与目标
你提出的评测方向已完全采纳：
- 不再只看单帧/精度；
- 转为序列路径 `eval/video_depth/launch.py`（天然多帧流式）；
- 增加系统指标以判断 KV/OBCache 的真实收益。

## 3. 代码改动（已生效）
本轮为了支持系统评测新增了以下能力：
- `video_depth` 支持 KV 开关与配置注入：
  - `--kv_cache_enable`
  - `--kv_cache_cfg_json`
- `video_depth/launch.py` 增加按序列系统统计与汇总输出：
  - `overall_fps`
  - `avg_latency_ms_per_frame`
  - `max_peak_allocated_mb`
  - `max_peak_reserved_mb`
  - 汇总文件：`system_metrics.json`
- `OBCache` 统计新增：
  - `evict_calls`
  - `evicted_tokens_total`
  - `appended_tokens_total`
  - `reused_tokens_total`
  - `cache_hit_rate`（由 reused/(reused+appended) 计算）
- `dust3r.inference -> StreamVGGTOutput` 透传 `kv_cache_stats`，供评测脚本落盘。

## 4. 运行记录（服务器）
- 机器：`msi_server (192.168.166.9:2222)`
- 环境：`conda env = obvggt`

### 4.1 retry1（部分完成后失败）
- Run: `20260304_130631_msi3_video_depth_sys_benchmark_obcache_retry1`
- 状态：`FAILED`
- 已完成：`sintel baseline + obcache`
- 失败点：`bonn baseline` 先 OOM，随后 `eval_depth.py` 在空预测上报错（`need at least one array to stack`）。

### 4.2 retry2（容错续跑，已完成）
- Run: `20260304_194844_msi3_video_depth_sys_benchmark_obcache_retry2_continue`
- 状态：`DONE`
- 策略：空预测时跳过 `eval_depth`，继续后续数据集
- 已完成：`bonn baseline/obcache`、`kitti baseline/obcache`

## 5. 系统指标结果（核心）

| 数据集 | 方案 | 序列成功/总数 | OOM序列 | FPS | 单帧延迟(ms) | 峰值Allocated(MB) | 峰值Reserved(MB) | KV命中率 | Evict Calls | Evicted Tokens |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| sintel | baseline | 23/23 | 0 | 6.7931 | 147.2076 | 11661.7446 | 23792.0 | 0.0000 | 0 | 0 |
| sintel | obcache | 23/23 | 0 | 5.6920 | 175.6856 | 8168.8594 | 9874.0 | 0.8648 | 21672 | 12136320 |
| bonn | baseline | 0/5 | 5 | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| bonn | obcache | 5/5 | 0 | 4.0034 | 249.7849 | 10777.4331 | 11662.0 | 0.8709 | 12360 | 12409440 |
| kitti | baseline | 13/13 | 0 | 6.7041 | 149.1630 | 14504.3159 | 23868.0 | 0.0000 | 0 | 0 |
| kitti | obcache | 13/13 | 0 | 6.1431 | 162.7840 | 8263.3633 | 10410.0 | 0.8704 | 28272 | 11648064 |

### 5.1 变化量（仅可比 pair）
- `sintel`:
  - FPS: `-16.21%`
  - Reserved 显存: `-58.50%`
- `kitti`:
  - FPS: `-8.37%`
  - Reserved 显存: `-56.39%`
- `bonn`:
  - baseline `0/5` vs obcache `5/5`（从不可用到可用）

## 6. 深度精度结果（result_scale.json）

| 数据集 | 方案 | Abs Rel | Sq Rel | RMSE | Log RMSE | δ<1.25 | δ<1.25^2 | δ<1.25^3 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| sintel | baseline | 0.3267 | 1.4858 | 3.8170 | 0.3718 | 0.6508 | 0.8201 | 0.8994 |
| sintel | obcache | 0.3351 | 1.4666 | 3.8421 | 0.3859 | 0.6406 | 0.8077 | 0.8917 |
| bonn | baseline | N/A（OOM） | N/A | N/A | N/A | N/A | N/A | N/A |
| bonn | obcache | 0.0563 | 0.0353 | 0.2584 | 0.1134 | 0.9728 | 0.9843 | 0.9897 |
| kitti | baseline | 0.1728 | 0.9324 | 4.9661 | 0.2173 | 0.7219 | 0.9444 | 0.9930 |
| kitti | obcache | 0.1674 | 0.9338 | 4.8969 | 0.2110 | 0.7610 | 0.9477 | 0.9925 |

说明：
- `kitti` 上 obcache 精度略优（AbsRel/RMSE/δ<1.25）。
- `sintel` 上 obcache 精度略降。
- 这说明 OBCache 改动对精度影响是“数据集相关”的，主收益依然在系统维度。

## 7. 关键结论
1. **显存收益确定**：在 `sintel` 与 `kitti`，reserved 峰值显存均大幅下降（约 56%~59%）。
2. **鲁棒性收益确定**：`bonn baseline` 完全不可运行（OOM），`obcache` 可完整跑通。
3. **吞吐代价存在**：`sintel/kitti` 下 FPS 分别下降约 16% 与 8%。
4. **精度非单向变化**：`kitti` 有提升、`sintel` 有下降；应按任务加权取舍。

## 8. 风险与限制
- `bonn` 的 baseline 精度缺失（因全 OOM），无法给出 bonn 精度对照，只能给“可运行性对照”。
- 当前报告聚焦 `video_depth`。`mv_recon`/`pose` 的系统指标口径尚未统一到同一套表。
- `cache_hit_rate` 目前定义为 `reused_tokens / (reused_tokens + appended_tokens)`，属于工程统计口径，不等价于 attention-level 命中。

## 9. 建议下一步（可直接执行）
1. 加一组 `bonn baseline` 降负载对照（例如降分辨率/分块），拿到可比精度曲线。
2. 补 `mv_recon` 同口径系统指标，验证“显存收益是否能迁移到重建任务”。
3. 形成最终决策矩阵（按业务优先级）：
   - 如果优先“跑得动/省显存”：默认 OBCache。
   - 如果优先“纯吞吐”：baseline 可能更好。
   - 如果优先“精度”：按数据集单独选择。

## 10. 证据路径（服务器）
- `sintel`：
  - baseline: `/mnt/data2/OBVGGT/code/OBVGGT/eval_results/video_depth_sys_retry1/sintel_OBVGGT_baseline/system_metrics.json`
  - obcache: `/mnt/data2/OBVGGT/code/OBVGGT/eval_results/video_depth_sys_retry1/sintel_OBVGGT_obcache/system_metrics.json`
- `bonn`：
  - baseline: `/mnt/data2/OBVGGT/code/OBVGGT/eval_results/video_depth_sys_retry2/bonn_OBVGGT_baseline/system_metrics.json`
  - obcache: `/mnt/data2/OBVGGT/code/OBVGGT/eval_results/video_depth_sys_retry2/bonn_OBVGGT_obcache/system_metrics.json`
- `kitti`：
  - baseline: `/mnt/data2/OBVGGT/code/OBVGGT/eval_results/video_depth_sys_retry2/kitti_OBVGGT_baseline/system_metrics.json`
  - obcache: `/mnt/data2/OBVGGT/code/OBVGGT/eval_results/video_depth_sys_retry2/kitti_OBVGGT_obcache/system_metrics.json`
- 运行记录：
  - `/mnt/data2/OBVGGT/runs/records/20260304_130631_msi3_video_depth_sys_benchmark_obcache_retry1.md`
  - `/mnt/data2/OBVGGT/runs/records/20260304_194844_msi3_video_depth_sys_benchmark_obcache_retry2_continue.md`
