# StreamVGGT 官方仓库评测报告（3号机）

## 1. 结论
- 任务状态：**已结束**（脚本执行到 `DONE`）
- 覆盖情况：`sintel / bonn / kitti / nyu` 指标已产出；`scannet` 仅完成推理，评测失败
- 失败原因：`eval/monodepth/eval_metrics.py` 在 `scannet` 分支触发 `NotImplementedError`

## 2. 运行信息
- 服务器：`192.168.166.9:2222`
- 代码仓库：`/mnt/data2/OBVGGT/code/StreamVGGT_github`
- 代码版本：`main@05682bc`
- 运行目录：`/mnt/data2/OBVGGT/runs/runs/20260304_110508_msi3_streamvggt_github_monodepth_full`
- 日志文件：`/mnt/data2/OBVGGT/runs/runs/20260304_110508_msi3_streamvggt_github_monodepth_full/monodepth.log`
- 结果目录：`/mnt/data2/OBVGGT/runs/eval_results_streamvggt_github/monodepth`

## 3. 时间线（日志关键节点）
- `2026-03-04 11:05:09` START StreamVGGT_github monodepth full
- `11:05:09` launch sintel
- `11:08:22` metrics sintel
- `11:08:43` launch bonn
- `11:10:53` metrics bonn
- `11:11:00` launch kitti
- `11:14:35` metrics kitti
- `11:14:48` launch nyu
- `11:17:27` metrics nyu
- `11:17:38` launch scannet
- `11:49:21` metrics scannet
- `11:49:23` WARNING scannet metrics failed（NotImplementedError）
- `11:49:23` DONE StreamVGGT_github monodepth full

## 4. 指标汇总（已成功产出的 metric.json）

| 数据集 | Abs Rel | Sq Rel | RMSE | Log RMSE | δ < 1.25 | δ < 1.25^2 | δ < 1.25^3 |
|---|---:|---:|---:|---:|---:|---:|---:|
| sintel | 0.2543 | 1.4672 | 4.0014 | 0.3720 | 0.6851 | 0.8343 | 0.9005 |
| bonn | 0.0515 | 0.0346 | 0.2399 | 0.1036 | 0.9711 | 0.9837 | 0.9895 |
| kitti | 0.0718 | 0.3916 | 3.8340 | 0.1209 | 0.9468 | 0.9852 | 0.9934 |
| nyu | 0.0550 | 0.0326 | 0.2768 | 0.0953 | 0.9585 | 0.9881 | 0.9953 |

## 5. 完整性检查
- 已存在：
  - `sintel_StreamVGGT/metric.json`
  - `bonn_StreamVGGT/metric.json`
  - `kitti_StreamVGGT/metric.json`
  - `nyu_StreamVGGT/metric.json`
- 缺失：
  - `scannet_StreamVGGT/metric.json`

## 6. 异常记录
日志异常片段：
- `Traceback (most recent call last)`
- `raise NotImplementedError`
- `NotImplementedError`

说明：该异常发生在 `metrics scannet` 阶段，不影响前四个数据集的 metric 结果落盘。
